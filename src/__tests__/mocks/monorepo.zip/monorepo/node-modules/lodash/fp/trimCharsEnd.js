var convert = require('./convert'),
    func = convert('trimCharsEnd', require('../trimEnd'));

func.placeholder = require('./placeholder');
module.exports = func;
