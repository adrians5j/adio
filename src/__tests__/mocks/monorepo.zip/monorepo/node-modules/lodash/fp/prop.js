module.exports = require('./get');
